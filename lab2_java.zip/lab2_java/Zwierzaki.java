package lab2;

public interface Zwierzaki {
    void jedzenie();
    void ruch();
    void sen();

}
